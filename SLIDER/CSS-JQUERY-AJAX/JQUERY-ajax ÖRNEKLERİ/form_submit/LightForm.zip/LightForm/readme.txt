
Name: LightForm
Version: 1.1
Demo URI: http://web-kreation.com/demos/LightForm
Author: Jeremie Tisseau
Author URI: http://web-kreation.com/

Download: http://web-kreation.com/index.php/freebies/

	Released under the Creative Commons Attribution v2.5.License.

===========
INSTALLATION
===========

- Unzip the file.
- Upload the files and folders to your server.
- Modify code as you wish.

======
USAGE
======

Open contact.php and change email line 55:
# $to = 'yourname@domain.com';

======
LICENSE
======

For any use or distribution of this theme, you must link back to my website and credit me for the original version of it. Please DO NOT REMOVE OR EDIT MY LINK.

This free template is released under the Creative Commons Attribution v2.5 (http://creativecommons.org/licenses/by/2.5/). This means that you are free:

    * to copy, distribute, display, and perform the work
    * to make derivative works
    * to make commercial use of the work

Under the following conditions:

    * You must attribute the work in the manner specified by the author or licensor. (In this case, leaving the link to my site in the sidebar at the bottom).
    * For any reuse or distribution, you must make clear to others the license terms of this work.
    * Any of these conditions can be waived if you get permission from the copyright holder.


=======
CONTACT
=======

Do not hesitate to contact me at info@web-kreation.com if you have any question.



