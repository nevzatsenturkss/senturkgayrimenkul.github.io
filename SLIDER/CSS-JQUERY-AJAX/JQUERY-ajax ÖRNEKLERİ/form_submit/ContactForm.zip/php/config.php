<?php
define('DB_SERVER'			, 'localhost');
define('DB_USER'			, 'root');
define('DB_PASS'			, '');
define('DB_NAME'			, 'ContactForm');

/*
 * Email Settings
 */
define('EMAIL_TO'			, 'codrops@gmail.com'); 
define('EMAIL_FROM_NAME'	, 'codrops');
define('EMAIL_FROM_ADDR'	, 'www.tympanus.net');
define('MESSAGE_SUBJECT'	, 'New Message From Contact Form');
define('SEND_EMAIL'			, true); /* if set to true, an email is sent to admin after a message is inserted */
?>