{
   "programlar":[
      {
         "isim":"Zone Alarm",
         "bilgi":"bilgisayarın güvenliğini sağlar",
         "adres":"www.zonealarm.com"
      },
      {
         "isim":"Opera",
         "bilgi":"güvenli ve hızlı bir web tarayıcısıdır",
         "adres":"www.opera.com"
      },
      {
         "isim":"Photoshop",
         "bilgi":"güçlü bir imaj işleme yazılımıdır",
         "adres":"www.adobe.com"
      }
   ]
}