<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>jQuery ve JSON işlemleri</title>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$('button').click( sonucAl );
	});
	
	function sonucAl()
	{
        var nesne = {isim:"Erhan", soyisim:"BURHAN", yas:24, web:"eburhan.com"};
        
        $('#sonuc').empty();

        $.each(nesne, function(ozellik, deger) {
            $('#sonuc').append(ozellik+': '+deger+'<br />');
        });
	}
</script>
<style type="text/css">
	button { cursor: pointer }
	code {
        background: #ffffcc;
        color: #666;
        padding: 5px
	}
	div {
		color:#666;
		font: normal 13px "Trebuchet MS";
		width: 350px;
		padding: 10px
	}
</style>
</head>
<body>

<p>$.each() fonksiyonu bir javaScript nesnesini işlemek...</p>
<p><code>{isim:"Erhan", soyisim:"BURHAN", yas:24, web:"eburhan.com"};</code></p>
<p><button type="button">Yukarıdaki nesneyi işle</button></p>

<br />
<br />

<div id="sonuc"></div>

</body>
</html>
