<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>jQuery ve JSON işlemleri</title>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$('button').click( sonucAl );
	});
	
	function sonucAl()
	{
		 $('#sonuc').html('alınıyor...');
		 
		 $.ajax({
		   url: 'program-bilgileri.php',
		   dataType: 'json',
		   success: function(JSON) {
                $('#sonuc').empty();

                $.each(JSON.programlar, function(i, program){
					$('#sonuc')
					.append(program.isim +'<br />')
					.append(program.bilgi+'<br />')
					.append(program.adres+'<hr />');
                });
		   }
		 });
	}
</script>
<style type="text/css">
	button { cursor: pointer }
	div {
		color:#666;
		font: normal 13px "Trebuchet MS";
		width: 350px;
		padding: 10px
	}
</style>
</head>
<body>

<p>$.ajax() fonksiyonu ile JSON verilerini işleme örneği...</p>
<p><button type="button">Program Bilgilerini Al</button></p>

<br />
<br />

<div id="sonuc">...</div>

</body>
</html>
